// Joey Van Melle : 20145502
// Tanguy Bulliard : 20126144

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import javax.swing.JFileChooser;

public class FileHandler {
	static JFileChooser fileChooser;
	
	public static File openFile() {
		fileChooser = new JFileChooser();
		int test = fileChooser.showOpenDialog(null);
		if (test == JFileChooser.APPROVE_OPTION) {
			File path = fileChooser.getSelectedFile();
			return path;
		}
		return null;
	}
	
	public static void saveFile(String content) {
		fileChooser = new JFileChooser();
		int test = fileChooser.showSaveDialog(null);
		if (test == JFileChooser.APPROVE_OPTION) {
			try {
				File path = fileChooser.getSelectedFile();
				OutputStreamWriter writer;
				if ((path.getAbsolutePath()).indexOf(".") == -1) {
					writer = new OutputStreamWriter(new FileOutputStream(path + ".txt"));
				} else {
					writer = new OutputStreamWriter(new FileOutputStream(path));
				}
				BufferedWriter bufferedWriter = new BufferedWriter(writer);
				bufferedWriter.write(content);
				bufferedWriter.close();
			} catch (Exception e) {
				System.err.format("IOException: %s%n", e);
			}
		}
	}
}
