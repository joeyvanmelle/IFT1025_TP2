// Joey Van Melle : 20145502
// Tanguy Bulliard : 20126144


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.Highlighter.HighlightPainter;
import javax.swing.text.Utilities;

public class DisplayFrame {
	private static JFrame frame;
	private static JTextArea textArea;
	private static HashSet<String> dict = new HashSet<String>();
	
	
	public static void main(String[] args) {
		DisplayFrame df = new DisplayFrame();
		dict.add("empty");
		df.displayFrame();		
	}
	
	private void displayFrame() {
		frame = new JFrame("Correcteur");
		
		//Menu Creation
		JMenuBar menu = new JMenuBar();
		
		//First element of the menu
		JMenu menuOption1 = new JMenu("Fichier");
		
		//Element in the list of the first option ("Fichier")
		menuOption1.add(new JMenuItem(new Open()));
		menuOption1.add(new JMenuItem(new Save()));
		
		//Other elements of the menu
		JButton menuOption2 = new JButton("Dictionnaire");
		JButton menuOption3 = new JButton("V�rifier");
		
		menuOption2.addActionListener(new Dictionnary());
		menuOption3.addActionListener(new Verification());
			
		menu.add(menuOption1);
		menu.add(menuOption2);
		menu.add(menuOption3);
		
		frame.setJMenuBar(menu);
		
		//Add JtextArea
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.addMouseListener(clickListener());
		frame.add(textArea);
		
		// Display the JFrame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setVisible(true);
	}
	
	public class Open extends AbstractAction {
		public Open() {
	        super("Ouvrir");
	    }
		//Loading of a file in JTextArea
	    public void actionPerformed(ActionEvent e) {
	    	try {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(FileHandler.openFile()), "UTF-8"));
	    		textArea.setText("");
	    		String line;
	    		while ((line = br.readLine()) != null) {
	    			textArea.append(line + " ");
	    		}
	    		br.close();
	    		
	    	} catch (IOException exception){
	    		JOptionPane.showMessageDialog(frame, "Erreur : impossible d'ouvrir le fichier.");
	    		System.err.println("Erreur : impossible d'ouvrir le fichier.\n" + exception.toString());
	    	}
	    }
	}
	
	//Save a file
	public class Save extends AbstractAction {
		public Save() {
	        super("Enregistrer");
	    }

	    public void actionPerformed(ActionEvent e) {
	    	FileHandler.saveFile(textArea.getText());
	    }
	}
	
	public class Dictionnary extends AbstractAction {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("loadDict");
			loadDict();
		}
	}
	//Load the dictionary 
	public static void loadDict() {
		dict = new HashSet<String>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("dict.txt"), "UTF-8"));
    		String line;
    		while ((line = br.readLine()) != null) {
    			dict.add(line);
    		}
    		br.close();
    		
    	} catch (IOException exception){
    		textArea.setText("Erreur : impossible d'ouvrir le dictionnaire.\n" + exception.toString());
    		System.err.println("Erreur : impossible d'ouvrir le dictionnaire.\n" + exception.toString());
    	}
	}
	
	public class Verification extends AbstractAction {

		@Override
		public void actionPerformed(ActionEvent e) {
			verify();
		}
	}
	
	//For each words in the JTextArea, verify that it is present in the dictionary
	public static void verify() {
		System.out.println("verification");
		if (dict.size() == 1 ) {
			JOptionPane.showMessageDialog(frame, "Chargement du dictionnaire par d�fault");
			loadDict();
		}
		if (textArea.getText().length() ==0 ) {
			JOptionPane.showMessageDialog(frame, "Votre texte est vide");
			return;
		}
		Highlighter hl = textArea.getHighlighter();
		hl.removeAllHighlights();
		HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(Color.pink);
		
		String[] text = textArea.getText().split("\\s");
		for (String word : text) {
			if (!dict.contains(word)){
				int index = 0;
				while (textArea.getText().indexOf(word, index) != -1) {
					try {
						//Highlight the words that are not in the dictionary
						hl.addHighlight(
								textArea.getText().indexOf(word, index), 
								textArea.getText().indexOf(word, index) + word.length(),
								painter 
						);
					} catch (BadLocationException e1) {
						e1.printStackTrace();
					}
					index = textArea.getText().indexOf(word, index) + 1;
				}
			}
		}
	}
	//Create a menu when a word is right clicked
	private static MouseListener clickListener() {
	    return new MouseAdapter() {
	    	@Override
	        public void mouseReleased(MouseEvent e) {
	    		if (SwingUtilities.isRightMouseButton(e)) {
	    			try {
	    				int position = textArea.viewToModel(e.getPoint());
	    				int start = Utilities.getWordStart(textArea, position);
	    				int end = Utilities.getWordEnd(textArea, position);
	    				String word = textArea.getText(start, end-start);
	    				if (dict.contains(word)) {
	    					return;
	    				}
		    			int rightClickPosition = textArea.viewToModel2D(e.getPoint());
		    			textArea.setCaretPosition(rightClickPosition);
		    			JPopupMenu popupMenu = wordChoicesMenu(word);
		    			popupMenu.show(textArea, e.getX(), e.getY());
	    			} catch (BadLocationException e1) {
	    				System.err.println(e1);
	    			}
	    		}
	        }
	   };
	}
	
	//Return a menu containing options to replace a word
	private static JPopupMenu wordChoicesMenu(String word) {
		JPopupMenu popupMenu = new JPopupMenu();
		String[] wordOptions = wordChoices(word);
		JMenuItem[] menus = new JMenuItem[5];
		//Ajouter les choix du menu
		for (int i = 0; i < 5; i++) {
			String wordOption = wordOptions[i];
			menus[i] = popupMenu.add(new JMenuItem(wordOptions[i]));
			//Ajouter l'effet du actionListener
			menus[i].addActionListener(a -> {
				//M�thode pour remplacer le mot
				try {
					int position = textArea.getCaretPosition();
					int start = Utilities.getWordStart(textArea, position);
					int end = Utilities.getWordEnd(textArea, position);
					textArea.replaceRange(wordOption, start, end);
					verify();
				} catch (Exception e1) {
					System.err.println(e1);
				}
			});
		}
		return popupMenu;
	}
	
	//Return options to correct a word
	public static String[] wordChoices(String word) {
		String[] wordOptions = new String[5];
		LinkedList<String> queue = new LinkedList<String>();
		Iterator<String> iter = dict.iterator(); 
        while (iter.hasNext()) {
            String s = iter.next();
        	if (queue.size() < 5) {
        		placeInQueue(queue, s, word);
            } else if (distance(word, s) <= distance(word, queue.getFirst())) {
            	placeInQueue(queue, s, word);
            	queue.remove();
            }
        }
        ListIterator<String> iter2 = queue.listIterator();
        int index = 0;
        while (iter2.hasNext()) {
        	wordOptions[index] = iter2.next();
        	index++;
        }
		return wordOptions;
	}
	
	//Queue to find the best replacing words
	public static void placeInQueue(LinkedList<String> queue, String s, String word) {
		ListIterator<String> iter = queue.listIterator();
		int index = 0;
		while (iter.hasNext()) {
			if (distance(word, s) >= distance(word, iter.next())) {
				queue.add(index, s);
				return;
			} else {
				index++;
			}
		}
		queue.addLast(s);
	}
	
	//Function that return the Levenshtein distance
	public static int distance(String s1, String s2){
	     int edits[][]=new int[s1.length()+1][s2.length()+1];
	     for(int i=0;i<=s1.length();i++)
	         edits[i][0]=i;
	     for(int j=1;j<=s2.length();j++)
	         edits[0][j]=j;
	     for(int i=1;i<=s1.length();i++){
	         for(int j=1;j<=s2.length();j++){
	             int u=(s1.charAt(i-1)==s2.charAt(j-1)?0:1);
	             edits[i][j]=Math.min(
	                             edits[i-1][j]+1,
	                             Math.min(
	                                edits[i][j-1]+1,
	                                edits[i-1][j-1]+u
	                             )
	                         );
	         }
	     }
	     return edits[s1.length()][s2.length()];
	}
	
	
}
